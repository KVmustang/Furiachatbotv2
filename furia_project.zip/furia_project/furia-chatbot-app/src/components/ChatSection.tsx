"use client";

import React, { useState, useEffect, useRef, useCallback } from 'react';
import io, { Socket } from 'socket.io-client';
import Image from 'next/image';
import EmojiPicker, { EmojiClickData } from 'emoji-picker-react';
import { motion } from 'framer-motion';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Smile, Send } from 'lucide-react';
import '@/styles/avatar.css';

// Define message interface
interface Message {
  sender: 'user' | 'bot';
  text: string;
  emotion?: string; // For bot messages to control avatar
}

// Define bot response interface
interface BotResponse {
  text: string;
  emotion: string;
}

// Mensagem de boas-vindas automática
const welcomeMessage: BotResponse = {
  text: "E aí, beleza? Sou o Furioso, o bot mais brabo da Furia! Tô aqui pra te contar tudo sobre a maior organização do Brasil! Pode perguntar sobre nossa história, times, conquistas ou qualquer coisa! #DIADEFURIA 🔥🐾",
  emotion: "happy"
};

// Função de fallback para quando o servidor não estiver disponível
// Usaremos as mesmas respostas do backend para consistência no modo offline
function getFallbackBotResponse(message: string): BotResponse {
  const lowerCaseMessage = message.toLowerCase().trim();
  let response = {
    text: "Opa! Parece que estou sem conexão com meus servidores agora, mas relaxa! Assim que voltar, respondo tudo. Enquanto isso, pode mandar um #DIADEFURIA!",
    emotion: "thinking" // Default emotion
  };

  // Basic greetings
  if (['oi', 'olá', 'ola', 'ei', 'e aí', 'eae', 'salve'].some(term => lowerCaseMessage.startsWith(term))) {
    response = { text: "E aí, beleza? Sou o Furioso, o bot mais brabo da Furia! Manda a pergunta que eu respondo. #DIADEFURIA", emotion: "happy" };
  } 
  // About Furia (General)
  else if (lowerCaseMessage.includes('quem é você') || lowerCaseMessage.includes('quem e voce') || lowerCaseMessage.includes('sobre você') || lowerCaseMessage.includes('sobre voce')) {
    response = { text: "Eu sou o Furioso! O bot oficial da Furia Esports. Tô aqui pra te contar tudo sobre a maior organização do Brasil! Pode perguntar!", emotion: "neutral" };
  } 
  else if (lowerCaseMessage.includes('furia') && (lowerCaseMessage.includes('história') || lowerCaseMessage.includes('historia') || lowerCaseMessage.includes('fundação') || lowerCaseMessage.includes('fundacao') || lowerCaseMessage.includes('começou') || lowerCaseMessage.includes('comecou'))) {
    response = { text: "A Furia nasceu GIGANTE em 2017! Começou com o sonho de Jaime Pádua, Akkari, Cris Guedes e guerri de levar o Brasil pro topo do CS. Hoje, somos muito mais: um movimento que une performance, lifestyle e paixão!", emotion: "happy" };
  } 
  else if (lowerCaseMessage.includes('fundadores') || lowerCaseMessage.includes('criou') || lowerCaseMessage.includes('dono')) {
    response = { text: "A Furia foi fundada por Jaime Pádua, André Akkari, Cris Guedes e Nicholas 'guerri' Nogueira. Uma galera visionária que acreditou no sonho!", emotion: "neutral" };
  } 
  else if (lowerCaseMessage.includes('origem') || lowerCaseMessage.includes('nasceu') || lowerCaseMessage.includes('onde')) {
    response = { text: "Nossa história começou lá em Uberlândia, Minas Gerais, em 2017. De lá, ganhamos o Brasil e o mundo!", emotion: "neutral" };
  } 
  else if (lowerCaseMessage.includes('movimento sociocultural') || lowerCaseMessage.includes('propósito') || lowerCaseMessage.includes('proposito')) {
    response = { text: "A Furia é mais que esports! Somos um movimento sociocultural. Queremos impactar positivamente, unir pessoas e alimentar sonhos, dentro e fora do jogo. É sobre lifestyle, conteúdo, business, tecnologia e social!", emotion: "happy" };
  } 
  else if (lowerCaseMessage.includes('pantera') || lowerCaseMessage.includes('logo')) {
    response = { text: "A pantera no nosso peito representa nossa garra, agilidade e instinto predador! É o símbolo da nossa força e da busca incessante pela vitória! PRA CIMA!", emotion: "fury" };
  }
  // About Teams/Modalities
  else if (lowerCaseMessage.includes('times') || lowerCaseMessage.includes('modalidades') || lowerCaseMessage.includes('jogos')) {
    response = { text: "A Furia compete em várias frentes! Temos times fortes no CS2, League of Legends (LoL), Valorant, Rocket League, Rainbow Six Siege (R6) e mais! Sempre buscando o topo em todas as modalidades!", emotion: "neutral" };
  } 
  else if (lowerCaseMessage.includes('cs') || lowerCaseMessage.includes('counter-strike') || lowerCaseMessage.includes('cs2')) {
    response = { text: "Nosso time de CS2 é LENDA! Já fizemos história em Majors, ganhamos títulos importantes e mostramos a força do Brasil pro mundo! A line-up tá sempre buscando evoluir, mas a garra é a mesma! #DIADEFURIA", emotion: "happy" };
  } 
  else if (lowerCaseMessage.includes('lol') || lowerCaseMessage.includes('league of legends')) {
    response = { text: "No LoLzinho, a Furia também marca presença forte no CBLOL! Estamos sempre na briga pelo título, mostrando raça e estratégia no Rift!", emotion: "neutral" };
  } 
  else if (lowerCaseMessage.includes('valorant')) {
    response = { text: "No Valorant, nosso time tá sempre buscando o topo nos campeonatos VCT! Muita bala, estratégia e a mira afiada pra representar a pantera!", emotion: "neutral" };
  }
  // About Achievements/Agenda
  else if (lowerCaseMessage.includes('conquistas') || lowerCaseMessage.includes('títulos') || lowerCaseMessage.includes('titulos') || lowerCaseMessage.includes('ganhou')) {
    response = { text: "Já levantamos troféus importantes! No CS, fomos campeões da ESL Pro League NA, Arctic Invitational, Elisa Masters... No LoL, já chegamos em finais do CBLOL. A busca por mais glórias nunca para!", emotion: "happy" };
  } 
  else if (lowerCaseMessage.includes('agenda') || lowerCaseMessage.includes('próximos jogos') || lowerCaseMessage.includes('proximos jogos') || lowerCaseMessage.includes('quando joga')) {
    response = { text: "Fica ligado nas nossas redes sociais oficiais! Lá a gente sempre posta a agenda completa de jogos de todos os times pra você não perder nenhum #DIADEFURIA!", emotion: "neutral" };
  }
  // About Furia Store/Partners
  else if (lowerCaseMessage.includes('loja') || lowerCaseMessage.includes('comprar camisa') || lowerCaseMessage.includes('produtos')) {
    response = { text: "Quer vestir o manto sagrado? Cola na nossa loja oficial em furia.gg! Tem jerseys, moletons, acessórios e muito mais pra você mostrar sua paixão pela Furia!", emotion: "happy" };
  } 
  else if (lowerCaseMessage.includes('patrocinadores') || lowerCaseMessage.includes('parceiros')) {
    response = { text: "Temos parceiros incríveis que acreditam no nosso sonho! Nike, Red Bull, Santander, PokerStars, Lenovo Legion e muitos outros gigantes que caminham junto com a Furia!", emotion: "neutral" };
  }
  // About Processo Seletivo
  else if (lowerCaseMessage.includes('processo seletivo') || lowerCaseMessage.includes('vaga') || lowerCaseMessage.includes('trabalhar na furia') || lowerCaseMessage.includes('emprego')) {
    response = { text: "Massa seu interesse em colar com a gente! Fica de olho nas nossas redes e no LinkedIn da Furia pra saber das vagas abertas. Geralmente rola análise de currículo, entrevistas e desafios técnicos. Boa sorte, futuro Furioso(a)!", emotion: "happy" };
  }
  // #DIADEFURIA & Farewell
  else if (lowerCaseMessage.includes('#diadefuria')) {
    response = { text: "É ISSO AÍ! #DIADEFURIA PRA CIMA DELES! QUEBRANDO TUDO! 🔥🐾", emotion: "fury" };
  }
  else if (lowerCaseMessage.includes('tchau') || lowerCaseMessage.includes('até mais') || lowerCaseMessage.includes('falou') || lowerCaseMessage.includes('valeu')) {
    response = { text: "Valeu! Tamo junto! Precisando, é só chamar. #DIADEFURIA", emotion: "happy" };
  }

  return response;
}

// Updated suggested questions array
const suggestedQuestions = [
  "Quem é você?",
  "Qual a história da Furia?",
  "Quem fundou a Furia?",
  "Quais times a Furia tem?",
  "Fale sobre o time de CS2",
  "E o time de LoL?",
  "Quais as maiores conquistas?",
  "Onde fica a loja da Furia?",
  "Quais são os patrocinadores?",
  "Como trabalhar na Furia?",
  "O que é o movimento sociocultural?",
  "#DIADEFURIA"
];

export default function ChatSection() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [socket, setSocket] = useState<Socket | null>(null);
  const [botEmotion, setBotEmotion] = useState('neutral');
  const [isBotTyping, setIsBotTyping] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null); // Ref for the end of messages
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 3;
  const welcomeMessageShown = useRef(false);

  // Exibir mensagem de boas-vindas automaticamente ao carregar
  useEffect(() => {
    if (!welcomeMessageShown.current && messages.length === 0) {
      welcomeMessageShown.current = true;
      setIsBotTyping(true);
      setBotEmotion('thinking');
      setTimeout(() => {
        setIsBotTyping(false);
        setMessages([{ 
          sender: 'bot', 
          text: welcomeMessage.text, 
          emotion: welcomeMessage.emotion 
        }]);
        setBotEmotion(welcomeMessage.emotion);
      }, 1500);
    }
  }, [messages.length]);

  // Restaurar Socket.IO connection logic
  useEffect(() => {
    const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5000';
    const newSocket = io(BACKEND_URL, {
      reconnectionAttempts: maxReconnectAttempts,
      timeout: 10000,
      transports: ['websocket', 'polling']
    });

    newSocket.on('connect', () => {
      console.log('Conectado ao servidor:', newSocket.id);
      setIsConnected(true);
      reconnectAttempts.current = 0;
    });

    newSocket.on('bot-message', (response: BotResponse) => {
      setIsBotTyping(false);
      setMessages(prev => [...prev, { 
        sender: 'bot', 
        text: response.text, 
        emotion: response.emotion 
      }]);
      setBotEmotion(response.emotion || 'neutral');
    });

    newSocket.on('connect_error', (error) => {
      console.error('Erro de conexão:', error);
      reconnectAttempts.current += 1;
      if (reconnectAttempts.current >= maxReconnectAttempts) {
        console.log('Máximo de tentativas de reconexão atingido, usando modo offline');
        setIsConnected(false);
      }
    });

    newSocket.on('disconnect', () => {
      console.log('Desconectado do servidor');
      setIsConnected(false);
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Improved Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isBotTyping]); // Trigger scroll on new messages or typing status change

  const sendMessage = useCallback(() => {
    if (inputValue.trim() && !isBotTyping) {
      const userMessage: Message = { sender: 'user', text: inputValue };
      setMessages(prev => [...prev, userMessage]);
      const userText = inputValue;
      setInputValue('');
      setIsBotTyping(true);
      setBotEmotion('thinking');

      if (isConnected && socket) {
        socket.emit('user-message', userText);
      } else {
        const thinkingTime = Math.random() * 1000 + 500;
        setTimeout(() => {
          const fallbackResponse = getFallbackBotResponse(userText);
          setIsBotTyping(false);
          setMessages(prev => [...prev, { 
            sender: 'bot', 
            text: fallbackResponse.text, 
            emotion: fallbackResponse.emotion 
          }]);
          setBotEmotion(fallbackResponse.emotion || 'neutral');
        }, thinkingTime);
      }
    }
  }, [inputValue, isBotTyping, socket, isConnected]);

  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(event.target.value);
  };

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      sendMessage();
    }
  };

  const handleEmojiClick = (emojiData: EmojiClickData) => {
    setInputValue(prev => prev + emojiData.emoji);
  };

  const handleSuggestedQuestionClick = (question: string) => {
    if (!isBotTyping) {
      const userMessage: Message = { sender: 'user', text: question };
      setMessages(prev => [...prev, userMessage]);
      setInputValue('');
      setIsBotTyping(true);
      setBotEmotion('thinking');

      if (isConnected && socket) {
        socket.emit('user-message', question);
      } else {
        const thinkingTime = Math.random() * 1000 + 500;
        setTimeout(() => {
          const fallbackResponse = getFallbackBotResponse(question);
          setIsBotTyping(false);
          setMessages(prev => [...prev, { 
            sender: 'bot', 
            text: fallbackResponse.text, 
            emotion: fallbackResponse.emotion 
          }]);
          setBotEmotion(fallbackResponse.emotion || 'neutral');
        }, thinkingTime);
      }
    }
  };

  return (
    // Aumentada a altura para 90vh e max-height para 900px
    <div className="bg-black/60 border border-border/30 rounded-lg shadow-xl flex flex-col h-[90vh] max-h-[900px] min-h-[500px] overflow-hidden">
      {/* Status indicator */}
      <div className="px-4 py-2 flex justify-end">
        <div className={`flex items-center text-xs ${isConnected ? 'text-green-500' : 'text-yellow-500'}`}>
          <span className={`inline-block w-2 h-2 rounded-full mr-1 ${isConnected ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
          {isConnected ? 'Conectado' : 'Modo Offline'}
        </div>
      </div>

      {/* Avatar Section - Reduzido o espaçamento */}
      <div className={`avatar-container my-2 ${botEmotion} ${isBotTyping ? 'thinking' : ''} ${messages.some(m => m.sender === 'bot' && m.emotion === 'talking') ? 'talking' : ''}`}>
         <Image
            src="/panther_avatar_3d_style.svg"
            alt="Avatar Furioso"
            width={160}
            height={160}
            className="avatar"
            priority
         />
      </div>

      {/* Message Area - Aumentada a altura com flex-grow-[4] */}
      <ScrollArea className="flex-grow-[4] p-4" ref={scrollAreaRef}>
        <div className="space-y-4 pr-2" ref={viewportRef}>
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] p-3 rounded-lg shadow-md ${msg.sender === 'user' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-gray-800 text-gray-100 rounded-bl-none'}`}>
                {msg.text}
              </div>
            </motion.div>
          ))}
          {isBotTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="flex justify-start"
            >
              <div className="max-w-[70%] p-3 rounded-lg bg-gray-800 text-gray-100 rounded-bl-none">
                <div className="flex items-center space-x-1">
                  <span className="typing-dot"></span>
                  <span className="typing-dot animation-delay-200"></span>
                  <span className="typing-dot animation-delay-400"></span>
                </div>
              </div>
            </motion.div>
          )}
          {/* Empty div at the end for auto-scroll target */}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area - Agora vem antes das sugestões */}
      <div className="p-3 border-t border-border/30 flex items-center gap-2 bg-gray-900/80">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
              <Smile className="h-5 w-5" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 border-none mb-2">
            <EmojiPicker onEmojiClick={handleEmojiClick} theme="dark" />
          </PopoverContent>
        </Popover>
        <Input
          type="text"
          placeholder="Digite sua mensagem... #DIADEFURIA"
          value={inputValue}
          onChange={handleInputChange}
          onKeyPress={handleKeyPress}
          className="flex-grow bg-secondary border-border focus-visible:ring-1 focus-visible:ring-primary focus-visible:ring-offset-0"
          disabled={isBotTyping}
        />
        <Button onClick={sendMessage} className="btn-furia-primary" disabled={isBotTyping || !inputValue.trim()}>
          <Send className="h-5 w-5" />
        </Button>
      </div>

      {/* Suggested Questions - Movido para baixo da caixa de entrada */}
      <div className="p-2 border-t border-border/30 flex flex-wrap gap-2 justify-center bg-gray-800/60">
        <div className="w-full text-xs text-center text-gray-400 mb-1">Sugestões de perguntas:</div>
        {suggestedQuestions.map((q, i) => (
          <Button
            key={i}
            variant="outline"
            size="sm"
            className="text-xs h-7 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            onClick={() => handleSuggestedQuestionClick(q)}
            disabled={isBotTyping}
          >
            {q}
          </Button>
        ))}
      </div>

      {/* CSS for typing dots */}
      <style jsx>{`
        .typing-dot {
          display: inline-block;
          width: 6px;
          height: 6px;
          background-color: currentColor;
          border-radius: 50%;
          opacity: 0.6;
          animation: typing-blink 1.2s infinite;
        }
        .animation-delay-200 { animation-delay: 0.2s; }
        .animation-delay-400 { animation-delay: 0.4s; }
        @keyframes typing-blink {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}
