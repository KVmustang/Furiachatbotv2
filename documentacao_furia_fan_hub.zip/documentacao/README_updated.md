# Documentação Completa - FURIA Fan Hub

Este documento fornece uma visão detalhada do projeto FURIA Fan Hub, desenvolvido como parte de um desafio técnico. O objetivo é oferecer uma documentação clara e abrangente, adequada para um repositório GitHub, explicando a estrutura, funcionalidades, código e como executar o projeto.

## Visão Geral

O FURIA Fan Hub é uma aplicação web projetada para engajar os fãs da Furia Esports. Ele é composto por duas partes principais:

1.  **Landing Page:** Uma página de entrada estática (`index.html`) que apresenta o projeto e direciona os usuários para o componente principal.
2.  **Chatbot Furioso:** Uma interface de chat interativa construída com Next.js e TypeScript. O chatbot responde a perguntas sobre a Furia, seus times (especialmente CS2), história e outras informações relevantes. Ele foi projetado para se comunicar com um backend Node.js via Socket.IO para respostas em tempo real, mas também inclui um modo offline funcional.

## Funcionalidades Detalhadas

### Landing Page (`static_landing/index.html`)

*   **Apresentação:** Introduz o propósito do FURIA Fan Hub.
*   **Chamada para Ação (CTA):** Contém um botão claro que leva o usuário diretamente para a aplicação do chatbot.
*   **Design:** Apresenta um design simples e direto, utilizando HTML e CSS, com fontes temáticas (Orbitron e Roboto) e as cores da Furia.
*   **Responsividade:** O layout se adapta a diferentes tamanhos de tela (design responsivo básico).
*   **Disclaimer:** Informa que se trata de um projeto de desafio técnico e não um produto oficial da Furia.

### Chatbot Furioso (`furia-chatbot-app/src/components/ChatSection.tsx`)

*   **Interface de Chat:** Exibe a conversa entre o usuário e o bot em um formato familiar de mensagens.
*   **Comunicação em Tempo Real:** Utiliza Socket.IO para conectar-se a um servidor backend (não incluído no zip, mas descrito no README original) para obter respostas dinâmicas.
*   **Modo Offline:** Possui uma lógica de fallback (`getFallbackBotResponse`) que fornece respostas pré-definidas caso a conexão com o backend falhe ou não esteja disponível. Isso garante que o chatbot permaneça funcional.
*   **Avatar Dinâmico:** Apresenta um avatar animado de uma pantera (o mascote "Furioso") que muda de emoção (`happy`, `fury`, `thinking`, `neutral`) com base no contexto da conversa ou no status do bot (digitando).
*   **Mensagem de Boas-Vindas:** Envia automaticamente uma mensagem introdutória ao carregar.
*   **Indicador de Status:** Mostra visualmente se o chatbot está conectado ao backend ("Conectado") ou operando em modo offline ("Modo Offline").
*   **Entrada de Usuário:** Permite que os usuários digitem suas perguntas, enviem emojis (usando `emoji-picker-react`) e enviem mensagens pressionando Enter ou clicando no botão de envio.
*   **Sugestões de Perguntas:** Apresenta botões com perguntas comuns para facilitar a interação do usuário.
*   **Feedback de Digitação:** Mostra um indicador visual quando o bot está "digitando" uma resposta.
*   **Tecnologias Frontend:** Construído com React (Next.js), TypeScript, Tailwind CSS para estilização, Shadcn/ui para componentes de UI, Framer Motion para animações e Socket.IO Client para comunicação.

## Estrutura do Projeto (Ideal)

Embora o arquivo `.zip` fornecido contenha apenas partes do frontend e a landing page estática, a estrutura completa do projeto, conforme descrito no `README.md` original, seria a seguinte:

```
furia_project/
├── backend/             # Servidor Node.js (Express + Socket.IO) - NÃO INCLUÍDO NO ZIP
│   ├── node_modules/
│   ├── .env             # Variáveis de ambiente (ex: PORT)
│   ├── package.json
│   ├── pnpm-lock.yaml
│   └── server.js        # Lógica do servidor e chatbot backend
├── furia-chatbot-app/   # Aplicação Frontend Next.js
│   ├── .next/           # Build do Next.js
│   ├── node_modules/
│   ├── public/          # Arquivos estáticos (imagens, avatar.svg, etc.)
│   ├── src/
│   │   ├── app/         # Páginas e layout do Next.js App Router
│   │   ├── components/  # Componentes React (ChatSection.tsx, etc.)
│   │   └── styles/      # Estilos CSS (avatar.css)
│   ├── .env.local       # Variáveis de ambiente do frontend (URL do backend)
│   ├── next.config.mjs
│   ├── package.json
│   ├── postcss.config.js
│   ├── tailwind.config.ts
│   └── tsconfig.json
├── static_landing/      # Diretório para deploy da landing page estática
│   └── index.html       # Landing page HTML
├── .gitignore
├── README.md            # O README original do projeto
└── roteiro_video_final.md # Roteiro para um vídeo de apresentação
```

*   **`backend/`**: Conteria o servidor Node.js responsável por receber mensagens do cliente via Socket.IO, processá-las (possivelmente usando alguma lógica de NLP ou regras) e enviar as respostas de volta. *Esta parte não foi incluída no arquivo zip fornecido.*
*   **`furia-chatbot-app/`**: O frontend Next.js que renderiza a interface do chat (`ChatSection.tsx`) e se comunica com o backend.
*   **`static_landing/`**: Contém a página HTML simples que serve como ponto de entrada.
*   **`roteiro_video_final.md`**: Um arquivo Markdown contendo um roteiro, provavelmente usado para gravar um vídeo demonstrando o projeto.

## Tecnologias Utilizadas

*   **Frontend:** Next.js, React, TypeScript, Tailwind CSS, Shadcn/ui, Socket.IO Client, Framer Motion, Emoji Picker React
*   **Backend (Ideal):** Node.js, Express, Socket.IO
*   **Linguagens:** TypeScript, JavaScript, HTML, CSS
*   **Gerenciador de Pacotes:** npm, pnpm (mencionado no README original para o backend)
*   **Hospedagem (Exemplo):** Manus (mencionado no README original para deploy estático e Next.js)


