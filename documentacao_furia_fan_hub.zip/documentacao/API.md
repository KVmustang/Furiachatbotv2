## Documentação da API e Código - FURIA Fan Hub (Frontend)

Este documento detalha a estrutura do código frontend do Chatbot Furioso, focando no componente principal `ChatSection.tsx` e na sua comunicação via Socket.IO.

### Componente Principal: `ChatSection.tsx`

Localizado em `furia-chatbot-app/src/components/ChatSection.tsx`, este é o componente React funcional que encapsula toda a lógica e interface do chatbot.

**Propósito:** Renderizar a interface de chat, gerenciar o estado da conversa, lidar com a entrada do usuário e comunicar-se com o backend (ou operar em modo offline).

#### Interfaces Definidas

```typescript
// Define a estrutura de uma mensagem na conversa
interface Message {
  sender: 'user' | 'bot'; // Quem enviou a mensagem
  text: string;          // O conteúdo da mensagem
  emotion?: string;       // Emoção associada (para mensagens do bot, controla o avatar)
}

// Define a estrutura da resposta esperada do bot (do backend ou fallback)
interface BotResponse {
  text: string;    // Texto da resposta do bot
  emotion: string; // Emoção que o bot deve expressar
}
```

#### Estados Principais (React `useState`)

*   `messages` (`Message[]`): Array que armazena o histórico da conversa. Cada item é um objeto `Message`.
*   `inputValue` (`string`): Armazena o texto atual no campo de entrada do usuário.
*   `socket` (`Socket | null`): Mantém a instância do objeto Socket.IO para comunicação com o backend.
*   `botEmotion` (`string`): Controla a emoção atual do avatar do bot (ex: 'neutral', 'happy', 'fury', 'thinking'). Afeta as classes CSS aplicadas ao avatar.
*   `isBotTyping` (`boolean`): Indica se o bot está atualmente "digitando" uma resposta. Usado para mostrar o indicador de digitação e desabilitar a entrada do usuário temporariamente.
*   `isConnected` (`boolean`): Indica se a conexão Socket.IO com o backend está ativa.

#### Funções Principais

*   `sendMessage()`: Chamada quando o usuário envia uma mensagem. Adiciona a mensagem do usuário ao estado `messages`, limpa o campo de entrada, define `isBotTyping` como `true`, e emite o evento `user-message` via Socket.IO (se conectado) ou chama `getFallbackBotResponse` (se offline).
*   `getFallbackBotResponse(message: string): BotResponse`: Função acionada no modo offline. Recebe a mensagem do usuário, realiza uma correspondência básica de palavras-chave (não sensível a maiúsculas/minúsculas) e retorna um objeto `BotResponse` pré-definido. As respostas tentam simular as que seriam dadas pelo backend.
*   `handleInputChange()`: Atualiza o estado `inputValue` conforme o usuário digita no campo de entrada.
*   `handleKeyPress()`: Detecta se a tecla Enter foi pressionada no campo de entrada para chamar `sendMessage()`.
*   `handleEmojiClick()`: Adiciona o emoji selecionado no `EmojiPicker` ao `inputValue`.
*   `handleSuggestedQuestionClick(question: string)`: Chamada quando um botão de sugestão é clicado. Funciona de forma semelhante a `sendMessage()`, enviando a pergunta sugerida diretamente.

#### Efeitos Colaterais (React `useEffect`)

*   **Conexão Socket.IO:** Um `useEffect` é responsável por inicializar a conexão Socket.IO quando o componente é montado. Ele configura os listeners para os eventos `connect`, `disconnect`, `connect_error`, e `bot-message`. Também lida com tentativas de reconexão e define o estado `isConnected`.
*   **Mensagem de Boas-Vindas:** Outro `useEffect` dispara uma única vez para enviar a mensagem de boas-vindas automática do bot logo após a montagem inicial do componente.
*   **Auto-Scroll:** Um `useEffect` observa mudanças nos estados `messages` e `isBotTyping` para rolar automaticamente a área de chat para a mensagem mais recente, garantindo que o usuário sempre veja as últimas interações.

### Comunicação via Socket.IO (Frontend)

A comunicação em tempo real com o backend é gerenciada pela biblioteca `socket.io-client`.

*   **Inicialização:** A conexão é estabelecida com a URL definida na variável de ambiente `NEXT_PUBLIC_BACKEND_URL` (fallback para `http://localhost:5000`).
    ```javascript
    const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:5000';
    const newSocket = io(BACKEND_URL, { /* opções */ });
    ```

*   **Eventos Emitidos (Cliente -> Servidor):**
    *   `user-message` (payload: `string`): Enviado quando o usuário manda uma mensagem. O payload é o texto da mensagem do usuário.
        ```javascript
        socket.emit('user-message', userText);
        ```

*   **Eventos Recebidos (Servidor -> Cliente):**
    *   `connect`: Disparado quando a conexão é estabelecida com sucesso. Define `isConnected` para `true`.
    *   `disconnect`: Disparado quando a conexão é perdida. Define `isConnected` para `false`.
    *   `connect_error`: Disparado quando ocorre um erro ao tentar conectar. Usado para contar tentativas de reconexão e, eventualmente, confirmar o estado offline.
    *   `bot-message` (payload: `BotResponse`): Recebe a resposta do bot vinda do servidor. O payload deve ser um objeto `BotResponse`. A função atualiza o estado `messages` com a resposta do bot e define `botEmotion` e `isBotTyping`.
        ```javascript
        newSocket.on('bot-message', (response: BotResponse) => {
          setIsBotTyping(false);
          setMessages(prev => [...prev, { sender: 'bot', text: response.text, emotion: response.emotion }]);
          setBotEmotion(response.emotion || 'neutral');
        });
        ```

### Animação do Avatar

A emoção do avatar é controlada dinamicamente pela adição de classes CSS ao elemento contêiner do avatar. O estado `botEmotion` (ex: 'happy', 'fury', 'thinking') é usado para determinar qual classe de emoção adicionar. Classes adicionais como `thinking` ou `talking` também podem ser adicionadas com base no estado `isBotTyping` ou em respostas específicas. As animações e estilos visuais correspondentes a essas classes seriam definidos em um arquivo CSS separado (como `avatar.css`, mencionado nos imports, mas não presente no zip).

```jsx
<div className={`avatar-container my-2 ${botEmotion} ${isBotTyping ? 'thinking' : ''} ...`}>
  <Image ... />
</div>
```

Esta documentação cobre os aspectos essenciais do código frontend fornecido, explicando como o componente `ChatSection.tsx` funciona e interage com o sistema.

