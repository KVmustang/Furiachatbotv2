## Guia de Instalação - FURIA Fan Hub

Este guia fornece as instruções passo a passo para configurar e executar o projeto FURIA Fan Hub em seu ambiente local. Siga estas etapas cuidadosamente para garantir que todos os componentes funcionem corretamente.

**Importante:** O arquivo `.zip` fornecido contém o código do frontend (`furia-chatbot-app`) e a landing page estática (`static_landing`). O código do backend Node.js, mencionado na estrutura do projeto e necessário para a funcionalidade completa do chatbot online, **não foi incluído** no arquivo zip. As instruções abaixo incluem os passos para configurar o backend, assumindo que você tenha acesso a esse código separadamente.

### Pré-requisitos

Antes de começar, certifique-se de ter o seguinte software instalado em sua máquina:

*   **Node.js:** Versão 18 ou superior recomendada. Você pode baixá-lo em [nodejs.org](https://nodejs.org/). O Node.js inclui o npm (Node Package Manager).
*   **pnpm (Opcional, para Backend):** O README original menciona o uso de `pnpm` para o backend. Se você for usar o backend original, instale o pnpm globalmente: `npm install -g pnpm`.
*   **Git:** Necessário para clonar o repositório (se aplicável).
*   **Python 3 (Opcional, para Landing Page):** Uma maneira fácil de servir a landing page estática localmente. A maioria dos sistemas já o possui instalado.

### 1. Obtenha o Código do Projeto

Se você estiver trabalhando a partir do arquivo zip fornecido:

*   Descompacte o arquivo `furia_fan_hub_final_v10.zip` em um diretório de sua escolha. Você terá uma pasta `furia_fan_hub` contendo `furia_project`.

Se você estiver clonando de um repositório Git (substitua `<URL_DO_REPOSITORIO>` pela URL real):

```bash
git clone <URL_DO_REPOSITORIO>
cd furia_project
```

### 2. Configuração do Backend (Se o código estiver disponível)

**Nota:** Estas etapas são baseadas no README original e pressupõem que você tenha o diretório `backend/`.

1.  **Navegue até o diretório do backend:**
    ```bash
    cd backend
    ```

2.  **Instale as dependências:**
    *   Usando pnpm (recomendado pelo README original):
        ```bash
        pnpm install
        ```
    *   Ou usando npm:
        ```bash
        npm install
        ```

3.  **Configure as variáveis de ambiente:**
    *   Crie um arquivo chamado `.env` dentro do diretório `backend/`.
    *   Adicione a seguinte linha, definindo a porta em que o servidor será executado (o padrão é 5000 se não for especificado):
        ```
        PORT=5000
        ```

4.  **Inicie o servidor backend:**
    ```bash
    node server.js
    ```
    *   O servidor backend estará em execução (por padrão em `http://localhost:5000`). Mantenha este terminal aberto.

5.  **Volte para o diretório raiz do projeto:**
    ```bash
    cd ..
    ```

### 3. Configuração do Frontend (Chatbot Next.js)

1.  **Navegue até o diretório do frontend:**
    ```bash
    cd furia-chatbot-app
    ```

2.  **Instale as dependências:**
    *   O README original recomenda usar `--legacy-peer-deps` devido a possíveis conflitos de versão do React com dependências como `cmdk`. Execute:
        ```bash
        npm install --legacy-peer-deps
        ```
    *   Se encontrar problemas, você pode tentar `npm install` normalmente, mas esteja ciente dos possíveis avisos de dependência.

3.  **Configure as variáveis de ambiente:**
    *   Crie um arquivo chamado `.env.local` dentro do diretório `furia-chatbot-app/`.
    *   Adicione a seguinte linha, especificando a URL onde o servidor backend está (ou estará) em execução:
        ```
        NEXT_PUBLIC_BACKEND_URL=http://localhost:5000
        ```
        *Certifique-se de que a porta corresponde à definida no `.env` do backend.*

4.  **Inicie o servidor de desenvolvimento do frontend:**
    ```bash
    npm run dev
    ```
    *   A aplicação Next.js estará em execução, geralmente em `http://localhost:3000`. Mantenha este terminal aberto.

5.  **Volte para o diretório raiz do projeto:**
    ```bash
    cd ..
    ```

### 4. Executando a Landing Page Estática

1.  **Navegue até o diretório da landing page:**
    ```bash
    cd static_landing
    ```

2.  **Inicie um servidor HTTP simples:**
    *   Usando Python 3:
        ```bash
        python3 -m http.server 8080
        ```
    *   Alternativamente, você pode usar outras ferramentas como `npx serve` ou extensões do VS Code (Live Server).
    *   A landing page estará acessível em `http://localhost:8080` (ou na porta que você escolher). Mantenha este terminal aberto.

### 5. Acessando a Aplicação

1.  Abra seu navegador web.
2.  Acesse a **Landing Page** em `http://localhost:8080`.
3.  Clique no botão "ACESSAR O CHATBOT".
4.  Você será redirecionado para a aplicação **Chatbot Furioso** em `http://localhost:3000`.

Agora você deve ter o ambiente local do FURIA Fan Hub configurado e em execução. Se o backend estiver rodando, o chatbot tentará se conectar a ele. Caso contrário, ele funcionará no modo offline usando as respostas de fallback definidas no código do frontend.

