# Roteiro de Vídeo - Apresentação FURIA Fan Hub (3 Minutos)

**Objetivo:** Apresentar o projeto FURIA Fan Hub desenvolvido para o desafio técnico, destacando as correções implementadas, funcionalidades e tecnologias utilizadas.

**Público:** Equipe de recrutamento e gestores da Furia Esports.

**Duração:** 3 minutos

---

## (0:00 - 0:20) Introdução

**(Visual: Tela inicial com seu nome e o logo da Furia)**

**Você:** Olá! Meu nome é [Seu Nome] e estou muito animado em apresentar o projeto que desenvolvi para o desafio técnico da vaga de Assistente de Engenheiro de Software na Furia Esports.

**Você:** O projeto FURIA Fan Hub é uma plataforma interativa para os fãs da Furia, que demonstra minhas habilidades em desenvolvimento full-stack, resolução de problemas e design de interface.

## (0:20 - 0:50) Landing Page e Navegação

**(Visual: Mostrar a Landing Page em https://usijmlre.manus.space)**

**Você:** Conforme solicitado, criei esta landing page funcional e hospedada online. Ela serve como porta de entrada para o projeto, apresentando o conceito do Fan Hub e direcionando o usuário para a aplicação principal do chatbot.

**Você:** A landing page foi construída com HTML, CSS e JavaScript, focando em um design limpo e responsivo que segue a identidade visual da Furia, com o característico preto e amarelo.

**(Visual: Clicar no botão "ACESSAR O CHATBOT" para navegar até a aplicação principal)**

**Você:** Ao clicar no botão, somos direcionados para a aplicação principal do chatbot, exatamente como solicitado nos requisitos.

## (0:50 - 1:30) Demonstração do Chatbot e Correções

**(Visual: Mostrar a interface do chatbot em https://qvszcivj.manus.space)**

**Você:** Esta é a aplicação principal do FURIA Fan Hub. Um dos principais desafios que identifiquei e corrigi foi o problema de conexão do chatbot com o servidor backend.

**Você:** O código original tinha a funcionalidade Socket.IO removida e substituída por uma simulação local, o que causava as mensagens de erro "não consigo me conectar ao servidor".

**(Visual: Interagir com o chatbot, fazendo perguntas como "Quem é você?" ou "#DIADEFURIA")**

**Você:** Restaurei a implementação Socket.IO completa e adicionei um modo offline de fallback, garantindo que o chatbot sempre responda, mesmo se houver problemas temporários de conexão com o servidor.

**Você:** O Furioso, representado por este avatar da pantera, responde a perguntas sobre a Furia, o time de CS2, a história da organização e outros tópicos relacionados.

## (1:30 - 2:00) Estrutura e Tecnologias

**(Visual: Navegar entre as abas "Chatbot Furioso", "Time CS2" e "Quiz Furia")**

**Você:** A aplicação está estruturada em três seções principais: o Chatbot Furioso para interação, informações sobre o Time CS2, e um Quiz interativo sobre a Furia.

**Você:** Para o desenvolvimento, utilizei:
- Next.js e React 19 para o frontend, com TypeScript para maior segurança de tipos
- Socket.IO para comunicação em tempo real entre o frontend e o backend
- Node.js com Express para o servidor backend
- Tailwind CSS e componentes Shadcn/ui para a estilização
- Framer Motion para animações suaves

## (2:00 - 2:30) Desafios e Soluções

**Você:** Durante o desenvolvimento, enfrentei alguns desafios técnicos importantes:

**(Visual: Mostrar o indicador de status de conexão no chatbot)**

**Você:** Além de restaurar a conexão Socket.IO, implementei um indicador de status que mostra claramente ao usuário se o chatbot está conectado ao servidor ou operando em modo offline.

**(Visual: Mostrar o código ou a estrutura do projeto)**

**Você:** Outro desafio foi a compatibilidade entre o React 19 e algumas dependências que esperavam React 18. Resolvi isso utilizando flags de compatibilidade e garantindo que todas as funcionalidades continuassem operando corretamente.

**Você:** Também organizei o código em uma estrutura clara e bem documentada, facilitando futuras manutenções e expansões do projeto.

## (2:30 - 3:00) Conclusão e Entrega

**(Visual: Mostrar novamente a landing page e o chatbot funcionando)**

**Você:** O FURIA Fan Hub agora está completamente funcional, com:
- Uma landing page hospedada em https://usijmlre.manus.space
- O chatbot funcionando em https://qvszcivj.manus.space
- Código-fonte organizado e documentado no GitHub
- README detalhado com instruções para execução local

**Você:** Este projeto demonstra minha capacidade de identificar e resolver problemas técnicos, implementar funcionalidades completas e entregar um produto final de qualidade.

**Você:** Agradeço muito a oportunidade de participar deste desafio e estou à disposição para esclarecer qualquer dúvida sobre o desenvolvimento. Muito obrigado!

---

## Observações para Gravação:

- Ensaie o roteiro para garantir que você se encaixe nos 3 minutos.
- Prepare as telas e transições que você vai mostrar durante a gravação.
- Destaque os links da landing page e do chatbot no vídeo.
- Fale com naturalidade e entusiasmo sobre as soluções que você implementou.
- Mencione especificamente como você resolveu o problema de conexão do chatbot, que era o principal requisito técnico.
