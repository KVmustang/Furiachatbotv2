## Guia de Uso - FURIA Fan Hub

Este guia explica como interagir com a aplicação FURIA Fan Hub, focando principalmente na funcionalidade do Chatbot Furioso.

### Acessando a Aplicação

1.  **Landing Page:** Comece acessando a landing page (por exemplo, `http://localhost:8080` se estiver executando localmente, ou a URL de deploy fornecida).
2.  **Entrar no Chatbot:** Na landing page, clique no botão "ACESSAR O CHATBOT". Isso o redirecionará para a aplicação principal do chatbot (por exemplo, `http://localhost:3000` localmente).

### Interface do Chatbot Furioso

Ao acessar a aplicação do chatbot, você verá a seguinte interface:

*   **Área de Mensagens:** O painel principal onde a conversa entre você e o Furioso é exibida. Suas mensagens aparecem à direita, e as do bot à esquerda.
*   **Avatar do Furioso:** No topo (ou em uma seção destacada), você verá o avatar da pantera, o "Furioso". A aparência do avatar pode mudar para refletir diferentes emoções (feliz, pensando, furioso, neutro) com base na conversa ou se ele está "digitando".
*   **Indicador de Status:** Geralmente localizado no canto superior direito, este indicador mostra se o chatbot está "Conectado" ao servidor backend (verde) ou em "Modo Offline" (amarelo). No modo offline, as respostas são pré-definidas.
*   **Área de Entrada de Texto:** Na parte inferior, há um campo onde você pode digitar suas perguntas ou mensagens para o bot.
*   **Botão de Emoji:** Ao lado do campo de entrada, um ícone de sorriso permite abrir um seletor de emojis para adicionar às suas mensagens.
*   **Botão Enviar:** Um botão (geralmente com um ícone de envio) para mandar sua mensagem digitada.
*   **Sugestões de Perguntas:** Abaixo da área de entrada, podem aparecer botões com perguntas pré-sugeridas. Clicar em um desses botões enviará a pergunta diretamente ao bot.

### Interagindo com o Furioso

1.  **Mensagem de Boas-Vindas:** Ao carregar, o Furioso enviará automaticamente uma mensagem de boas-vindas.
2.  **Fazendo Perguntas:**
    *   **Digite sua pergunta:** Use o campo de entrada na parte inferior para digitar sua pergunta sobre a Furia, times, história, etc.
    *   **Use as Sugestões:** Clique em um dos botões de "Sugestões de Perguntas" para enviar uma pergunta comum rapidamente.
3.  **Enviando a Mensagem:**
    *   Pressione a tecla `Enter` após digitar sua mensagem.
    *   Ou clique no botão "Enviar".
4.  **Recebendo Respostas:**
    *   Você verá um indicador de "digitando" (geralmente três pontos animados) enquanto o bot prepara a resposta.
    *   A resposta do Furioso aparecerá na área de mensagens, vindo do lado esquerdo.
    *   Observe a emoção do avatar, que pode mudar com a resposta.
5.  **Usando Emojis:** Clique no botão de emoji, selecione o emoji desejado e ele será adicionado ao campo de entrada.

### Entendendo os Modos

*   **Modo Online (Conectado):** Se o indicador mostrar "Conectado", o chatbot está se comunicando com o servidor backend para obter respostas potencialmente mais dinâmicas e atualizadas (dependendo da implementação do backend).
*   **Modo Offline:** Se o indicador mostrar "Modo Offline", o chatbot não conseguiu se conectar ao backend. Ele ainda funcionará, mas usará um conjunto pré-definido de respostas (`getFallbackBotResponse` no código `ChatSection.tsx`). As respostas podem ser mais limitadas neste modo.

### Outras Seções (Conforme README Original)

O README original menciona que a aplicação completa teria abas ou seções adicionais como "Time CS2" e "Quiz Furia". A interação dentro dessas seções dependeria de sua implementação específica, que não está detalhada no código `ChatSection.tsx` fornecido no arquivo zip.

Este guia deve ajudá-lo a navegar e interagir efetivamente com o Chatbot Furioso no FURIA Fan Hub.

